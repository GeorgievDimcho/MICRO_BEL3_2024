/*
 * helperFunctions.h
 *
 *  Created on: Sep 13, 2021
 *      Author: Stefan Paschek
 */

#ifndef INC_HELPERFUNCTIONS_H_
#define INC_HELPERFUNCTIONS_H_
#include "main.h"

// ******Definitions******
#define RESET_LOW_ACT GPIO_PIN_SET
#define SET_LOW_ACT GPIO_PIN_RESET
#define RED_LED GPIO_PIN_6
#define GREEN_LED GPIO_PIN_8
#define BLUE_LED GPIO_PIN_4

// Register to read the ID
#define REG_ID 0x0E
  // Calculate read Register bit set on
#define REG_ID_R REG_ID|0x80
//************************


// ******Functionheaders********
uint8_t checkBit(uint32_t, uint8_t);
void writeRGBLED(char ,uint8_t);


// SPI Functions
HAL_StatusTypeDef read8SPI(SPI_HandleTypeDef, uint8_t, uint16_t *);
HAL_StatusTypeDef read16SPI(SPI_HandleTypeDef, uint8_t, uint16_t *);

//******************************

#endif /* INC_HELPERFUNCTIONS_H_ */
