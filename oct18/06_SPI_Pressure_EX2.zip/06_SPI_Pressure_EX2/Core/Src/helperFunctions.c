/*
 * helperFunctions.c
 *
 *  Created on: Sep 13, 2021
 *      Author: Stefan Paschek
 */
#include "helperFunctions.h"
#define MPL3115A2_ADDRESS 0x60  // I2C address for MPL3115A2
#define REG_CTRL_REG1 0x26
#define REG_OUT_P_MSB 0x01
#define REG_OUT_T_MSB 0x04
// This function checks if a bit in a register is set
// reg contains the registers value
// bitPosition contains the position which shall be checked in the register
// if the bit is set this function returns 1 otherwise 0
uint8_t checkBit(uint32_t reg, uint8_t bitPosition){
	return (reg>>bitPosition)&1;
}

void MPL3115A2_Init(I2C_HandleTypeDef *hi2c) {
    uint8_t ctrl_reg1 = 0xB9;  // Active mode, barometer mode, and enable data ready
    HAL_I2C_Mem_Write(hi2c, MPL3115A2_ADDRESS, REG_CTRL_REG1, 1, &ctrl_reg1, 1, HAL_MAX_DELAY);
}

void MPL3115A2_ReadData(I2C_HandleTypeDef *hi2c, float *pressure, float *altitude) {
    uint8_t data[5];  // Buffer to hold the data

    // Read pressure and temperature data
    HAL_I2C_Mem_Read(hi2c, MPL3115A2_ADDRESS, REG_OUT_P_MSB, 1, data, 5, HAL_MAX_DELAY);

    // Convert pressure data
    *pressure = ((data[0] << 16) | (data[1] << 8) | data[2]) / 64.0;  // Convert to pressure in Pa

    // Convert altitude data
    *altitude = ((data[3] << 8) | data[4]) / 16.0;  // Convert to altitude in meters
}


// This function enables or disables the led
void writeRGBLED(char selLED, uint8_t PinState){
	switch(selLED){
		case 'r': HAL_GPIO_WritePin(GPIOA, RED_LED, PinState);break;
		case 'g': HAL_GPIO_WritePin(GPIOA, GREEN_LED, PinState);break;
		case 'b': HAL_GPIO_WritePin(GPIOA, BLUE_LED, PinState);break;
		case 'a':
			HAL_GPIO_WritePin(GPIOA, RED_LED, PinState);
			HAL_GPIO_WritePin(GPIOA, GREEN_LED, PinState);
			HAL_GPIO_WritePin(GPIOA, BLUE_LED, PinState);break;
		default:break;
	}
}


// read 16 bit
HAL_StatusTypeDef read16SPI(SPI_HandleTypeDef hspi1, uint8_t reg, uint16_t *result){
	HAL_StatusTypeDef ret;
	uint8_t rcvBuf[4];
	// set receive array to 0 just be be sure
	rcvBuf[0]=0;
	rcvBuf[1]=0;
	rcvBuf[2]=0;
	// start communication cycle
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);

	// 3 bytes need to be read, 0 is the address, 1 is dummy, 2 is value
	ret = HAL_SPI_TransmitReceive(&hspi1, &reg, rcvBuf, 3,HAL_MAX_DELAY);

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);

	*result = (uint16_t)rcvBuf[3]<<8;
//	*result = *result<<8;
	*result |=rcvBuf[2];

 return ret;
}

// read 8 bit
HAL_StatusTypeDef read8SPI(SPI_HandleTypeDef hspi1, uint8_t reg, uint16_t *result){
	HAL_StatusTypeDef ret;
	uint8_t rcvBuf[3];
	// set receive array to 0 just be be sure
	rcvBuf[0]=0;
	rcvBuf[1]=0;
	rcvBuf[2]=0;
	// start communication cycle
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);

	// 3 bytes need to be read, 0 is the address, 1 is dummy, 2 is value
	ret = HAL_SPI_TransmitReceive(&hspi1, &reg, rcvBuf, 3,HAL_MAX_DELAY);

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);

	// store value to variable
	*result = rcvBuf[2];

 return ret;
}
