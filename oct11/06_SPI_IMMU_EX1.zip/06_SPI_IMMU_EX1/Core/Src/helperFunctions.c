/*
 * helperFunctions.c
 *
 *  Created on: Sep 13, 2021
 *      Author: Stefan Paschek
 */
#include "helperFunctions.h"

// This function checks if a bit in a register is set
// reg contains the registers value
// bitPosition contains the position which shall be checked in the register
// if the bit is set this function returns 1 otherwise 0
uint8_t checkBit(uint32_t reg, uint8_t bitPosition){
	return (reg>>bitPosition)&1;
}

// This function enables or disables the led
void writeRGBLED(char selLED, uint8_t PinState){
	switch(selLED){
		case 'r': HAL_GPIO_WritePin(GPIOA, RED_LED, PinState);break;
		case 'g': HAL_GPIO_WritePin(GPIOA, GREEN_LED, PinState);break;
		case 'b': HAL_GPIO_WritePin(GPIOA, BLUE_LED, PinState);break;
		case 'a':
			HAL_GPIO_WritePin(GPIOA, RED_LED, PinState);
			HAL_GPIO_WritePin(GPIOA, GREEN_LED, PinState);
			HAL_GPIO_WritePin(GPIOA, BLUE_LED, PinState);break;
		default:break;
	}
}
